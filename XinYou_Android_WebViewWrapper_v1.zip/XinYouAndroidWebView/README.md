# 心遇 XinYOU (Android WebView Wrapper)

這個專案是把你的 GitHub Pages（https://gn98004.github.io/leo-app-/）包成 Android App 的最小可用殼。

## 開啟方式
1. 安裝 Android Studio（包含 Android SDK）
2. 用 Android Studio 打開此資料夾
3. 等待 Gradle Sync 完成
4. Run（裝到手機）

## 產出上架檔（AAB）
Android Studio：Build → Generate Signed Bundle / APK → Android App Bundle

> 注意：簽章 keystore 請你自己建立並妥善保存。

## 入口網址
在 `app/src/main/java/com/xinyou/app/MainActivity.kt` 可修改 entryUrl。
